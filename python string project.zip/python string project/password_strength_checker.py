def check_password_strength(password):
    """Return the strength label and the password requirements that are met."""
    checks = {
        "At least 8 characters": len(password) >= 8,
        "An uppercase letter": any(character.isupper() for character in password),
        "A lowercase letter": any(character.islower() for character in password),
        "A digit": any(character.isdigit() for character in password),
        "A special character": any(
            not character.isalnum() for character in password
        ),
    }

    score = sum(checks.values())
    if score == len(checks):
        strength = "Strong"
    elif score >= 3:
        strength = "Medium"
    else:
        strength = "Weak"

    return strength, checks


def main():
    password = input("Enter a password to check: ")
    strength, checks = check_password_strength(password)

    print(f"\nPassword strength: {strength}")
    print("Requirements:")
    for requirement, is_met in checks.items():
        status = "Yes" if is_met else "No"
        print(f"- {requirement}: {status}")


if __name__ == "__main__":
    main()
